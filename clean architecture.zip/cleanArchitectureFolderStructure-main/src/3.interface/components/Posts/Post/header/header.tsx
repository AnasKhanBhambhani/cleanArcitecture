// dp and name of the user who posted the content
// date of publish
// side menu